import os
import sqlite3
from fastapi import FastAPI, Request
from datetime import datetime
import uvicorn

app = FastAPI()

DB_PATH = "trading.db"

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    # Ensure the table exists
    cursor.execute('''CREATE TABLE IF NOT EXISTS staged_stocks (
                        symbol TEXT, 
                        sentiment TEXT, 
                        timestamp DATETIME)''')
    conn.commit()
    conn.close()

@app.post("/alert")
async def handle_alert(tag: str, request: Request):
    data = await request.json()
    stocks = data.get("stocks", "")
    
    if not stocks:
        return {"status": "error", "message": "No stocks provided"}

    stock_list = [s.strip().upper() for s in stocks.split(",")]
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    for symbol in stock_list:
        cursor.execute(
            "INSERT INTO staged_stocks (symbol, sentiment, timestamp) VALUES (?, ?, ?)",
            (symbol, tag, datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        )
    
    conn.commit()
    conn.close()
    return {"status": "success", "count": len(stock_list)}

if __name__ == "__main__":
    init_db()
    uvicorn.run(app, host="0.0.0.0", port=8000)